OZMA - a music tracker for the TrimUI Brick (open beta)
=======================================================

INSTALL
-------
OZMA runs on the Brick's own Linux. The same files work on every OS below; only the folder differs.

  Brick OS                    Status
  spruce                      recommended, fully tested
  stock TrimUI OS, CrossMix   experimental: checked on the emulator, not yet on a Brick.
                              Please tell us how it works.
  NextUI                      EXPERIMENTAL, untested: OZMA appears in Tools (Tools/tg5040/OZMA.pak).
  Knulli                      EXPERIMENTAL: a separate OZMA Knulli zip.
  Other handhelds             EXPERIMENTAL, untested (Smart Pro, Brick Pro, Smart Pro S, Miyoo Flip, Anbernic
                              H700, muOS, ROCKNIX, ArkOS ...):
                              read App/OZMA/other-devices/README.txt.

1. Turn the Brick off and put the SD card in your computer.
2. Unzip OZMA-0.9.2-staging.3.zip into the ROOT of the card, merging folders. You get App/OZMA (the app) and
   Apps/OZMA (the menu entry for the stock OS). spruce shows OZMA from App, the stock OS from Apps.
3. Put the card back, turn the Brick on and open OZMA from the Apps menu.

Check the download: the file OZMA-0.9.2-staging.3.zip.sha256 next to the zip holds its SHA-256. Install only a zip
whose hash matches the one on the official page.

YOUR SONGS
----------
Your songs, samples and settings live in App/OZMA/data, shared by both OSes. To update, use PROJECT > UPDATE
over Wi-Fi (from 0.8.2 on), or unzip the new version the same way. The zip brings only the demo songs, OZMA KIT and the demos' own prints into data, so your songs
stay. A demo you change and SAVE goes to data/Songs as your own song; the demos themselves stay as they are.

This is a beta: back up the whole App/OZMA/data folder now and then (songs point to samples and recordings in it).

YOUR OWN SOUNDS
---------------
Put your own WAV files in the folder OZMA/Samples at the top of the SD card. OZMA makes this folder when it starts;
folders inside it are fine. The sample list shows them together with OZMA's own sounds. OZMA only reads this folder:
it never changes, moves or deletes a file in it. Sounds you already keep in App/OZMA/data/Samples stay there and keep
working. Back up OZMA/Samples together with App/OZMA/data.

DEMOS AND OZMA KIT
------------------
HELP > DEMOS opens three demo songs made only with OZMA's own instruments: DEEP FIELD (deep house), REDSHIFT
(techno) and ION DRIVE (drum and bass). Open them, take them apart, learn from them.
OZMA KIT (data/Samples/OZMA KIT) is a set of drum and FX sounds made for OZMA. You may use them in your own
music, also commercially (see LICENSE.txt).

STUDIO MODE AND RECOVERY
------------------------
While OZMA runs it puts the Brick in "studio mode": all CPU cores on, background services (sync, file sharing,
media server) paused. Everything is restored when you quit.
If OZMA was force-closed or crashed: open OZMA and quit it once more to bring those services back, or restart
the Brick.

USB: TWO PORTS, TWO JOBS
------------------------
TOP USB port = OZMA is the host. Plug in a MIDI keyboard or controller (for example an Arturia MiniLab), or a
class-compliant sound card or groovebox (for example an Elektron Tonverk). A device with a sound card gets the
Brick's audio and MIDI over one cable. Nothing to switch on: OZMA finds it when it is plugged in.
  PROJECT > AUDIO > OUTPUT   AUTO: a USB sound card on the top port takes over the sound while it is plugged in.
                             SPEAKER: the sound always stays on the Brick.
  PROJECT > MIDI > CLOCK OUT ON: OZMA sends tempo + start/stop, so the other device follows OZMA.
  PROJECT > MIDI > CLOCK IN AUTO: OZMA follows a clock it receives (press play on the master).

BOTTOM USB-C port = OZMA is the device. Plug it into a computer, phone or tablet: the Brick becomes a sound card +
MIDI port that needs no driver. It charges over the same cable.
  PROJECT > AUDIO > USB AUDIO   OUT: the Brick plays into the computer.  IN: the computer plays into the Brick.
                                OFF: the port works as usual. Takes effect the next time you start OZMA.
  PROJECT > AUDIO > BUFFER      bigger = no dropouts on a busy Brick, a little more delay.
  PROJECT > AUDIO > BRICK       while the computer records: the Brick plays too, or stays silent.

More detail and step-by-step setups: CHANGELOG.txt.

REPORTING A BUG
---------------
Join the OZMA Discord (https://discord.gg/uX7gvn2Ary) and make a post in #bugs, one bug per post. Please give the OZMA version
(App/OZMA/VERSION.txt), your Brick OS, what happened and how to make it happen again, and attach
App/OZMA/log.txt and App/OZMA/studio.log. To get these files: quit OZMA, turn the Brick off and put the SD card
in a computer or a phone (card reader). A phone video helps a lot for sound and screen problems.
On NextUI, Knulli and other handhelds OZMA also writes a tester report into App/OZMA after every run: a file whose
name starts with OZMA_REPORT_ (your device and system follow). Attach it too. It is made on your device only and is
never sent anywhere; it holds what OZMA found on the system, the end of the last run's log, checksums of OZMA's
own files and a random install number (made once on your card, not from your device). No passwords, no Wi-Fi
settings, no serial numbers. Open it to see everything it holds.

Official page: https://orumet.itch.io/ozma
LICENSE.txt: what you may do with OZMA. THIRD_PARTY_NOTICES.txt: the open-source parts and fonts inside.
