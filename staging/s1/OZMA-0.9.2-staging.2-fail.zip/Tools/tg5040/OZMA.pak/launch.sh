#!/bin/sh
# EXPERIMENTAL - untested on NextUI. NextUI / MinUI menu entry (SD/Tools/tg5040/OZMA.pak): those OSes list only .pak folders, so OZMA in SD/App/OZMA
# was invisible there. The app itself stays in SD/App/OZMA, shared with spruce and stock (same songs and settings).
# OZMA_ENTRY=pak: App/OZMA/platform/detect.sh then tells NextUI (it exports IS_NEXT=yes) from MinUI and loads that OS's
# profile (stick also as D-pad, the power key handled by OZMA, UPDATE notify-only: decisions D2, D3 of 2026-11-13).
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export OZMA_ENTRY=pak
exec "$HERE/../../../App/OZMA/launch.sh" "$@"
