#!/bin/sh
# EXPERIMENTAL - untested on every device it is meant for. OZMA is made for the TrimUI Brick.
# NextUI / MinUI menu entry for consoles other than the Brick / Smart Pro, shipped as SD/Tools/<platform>/OZMA.pak:
# tg5050 = TrimUI Smart Pro S, my355 = Miyoo Flip, h700 / rg35xxplus = Anbernic H700. Only hands over to the one app in
# SD/App/OZMA. Never runs on the Brick: NextUI / MinUI there list only Tools/tg5040 (scripts/brick/nextui/launch.sh).
# /bin/sh, no bashisms (bash is BusyBox on some TrimUI firmwares).
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
APP=$HERE/../../../App/OZMA
export OZMA_ENTRY=pak
# App/OZMA/platform/detect.sh picks the settings for this device and OS. Without it (an App/OZMA from before the platform
# layer): not the Brick's sound chip, so the system's own sound path, the stick also as a D-pad, no studio clocks.
[ -f "$APP/platform/detect.sh" ] || export BT_ALSA_DIRECT="${BT_ALSA_DIRECT:-0}" BT_STICK_AS_DPAD="${BT_STICK_AS_DPAD:-1}" BT_STUDIO="${BT_STUDIO:-0}"
exec sh "$APP/launch.sh" "$@"
