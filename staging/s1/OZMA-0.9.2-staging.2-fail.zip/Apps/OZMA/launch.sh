#!/bin/sh
# Stock TrimUI OS / CrossMix menu entry (SD/Apps/OZMA). The app itself lives once in SD/App/OZMA (the spruce
# folder), so one zip unpacked to the card root works on both OSes and both share the same songs and settings.
# OZMA_ENTRY tells App/OZMA/platform/detect.sh which menu started OZMA: from this one a spruce/ or .system/ folder on the
# card is a leftover of another OS, not the OS that runs.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export OZMA_ENTRY=apps
exec "$HERE/../../App/OZMA/launch.sh" "$@"
