#!/bin/sh
# Brick Tracker launcher (TrimUI Brick). Data lives next to the binary.
# Works on spruce (installed as /mnt/SDCARD/App/<folder>) and on the stock TrimUI OS or CrossMix
# (installed as /mnt/SDCARD/Apps/<folder>); both read the same config.json. Nothing below needs spruce:
# its busybox is only a fallback for stat, and services that are not running are simply not paused.
#
# STUDIO MODE (01.11.2026): while the tracker runs, the Brick works for music only,
# and everything is put back on exit (also on a crash or kill of the app, via the trap):
#   - all 4 cores online (older spruce Powersave kept only cpu0+cpu3): audio gets a core of its own,
#     UI another, workers the rest; cpu0 keeps every hardware IRQ (see src/platform/cores.h)
#   - CPU floor 816 MHz (as before), ceiling BT_CPU_MAX_KHZ (default 1608 MHz, or the user's higher max) under a thermal guard:
#     at >= 55 C the ceiling steps down one OPP, at <= 50 C it steps back up, so the kernel's own
#     passive throttling at 58 C is never reached. Every 2 s it also undoes a mid-session Powersave
#     switch by older spruce/PyUI (cores offlined, max/min changed; spruce 4.6.0 changes nothing mid-app: it pins
#     min = max = 1.8 GHz before the start, see set_max)
#   - background services paused with SIGSTOP (not killed): Syncthing, SFTPGo, Samba, TrimUI
#     musicserver, MTP. They continue exactly where they were on exit (SIGCONT)
#   - kept: analog audio/speaker, USB audio/MIDI, screen, charging, buttons/volume/power watchdogs,
#     WiFi + SSH (BT_STUDIO_WIFI=0 also blocks WiFi for the session)
# BT_STUDIO=0 runs the old way (only the 816 MHz floor). Changes are logged to studio.log.
#
# USB DEVICE MODE (kernel/ozma_usb, 02.11.2026; opt-in until the Brick soak test passes): BT_USB_GADGET=out
# (Brick plays into a computer/iPad on the bottom USB-C port) or in (the computer plays into the Brick)
# loads usb/ozma_usb.ko via usb/usb_mode.sh; the host sees a driverless "OZMA" sound card + MIDI port and
# keeps charging the Brick. On exit the module is unloaded and the stock adb gadget comes back. If the
# running kernel is not the one the module was built for, usb_mode.sh refuses and the app runs as usual.
APP_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$APP_DIR"
# IN-APP UPDATE (ozma_update.sh): before anything else, install an update the app downloaded and
# checked (.update/READY), undo an interrupted one, or put the old version back (ROLLBACK, or a new version that did
# not start). Exit 10 = files changed: run the (new) launch.sh from the top. Only renames inside APP_DIR.
export BT_APP_DIR="$APP_DIR"
if [ -f "$APP_DIR/ozma_update.sh" ]; then
    sh "$APP_DIR/ozma_update.sh" boot "$APP_DIR"; [ $? = 10 ] && exec sh "$APP_DIR/launch.sh" "$@"
    sh "$APP_DIR/ozma_update.sh" started "$APP_DIR"; [ $? = 10 ] && exec sh "$APP_DIR/launch.sh" "$@"
fi
export BT_DATA="${BT_DATA:-$APP_DIR/data}"
# a pad mapping file: the OS's own (muOS, PortMaster and others set SDL_GAMECONTROLLERCONFIG_FILE) wins over ours
[ -z "${SDL_GAMECONTROLLERCONFIG_FILE:-}" ] && [ -f "$APP_DIR/gamecontrollerdb.txt" ] && export SDL_GAMECONTROLLERCONFIG_FILE="$APP_DIR/gamecontrollerdb.txt"
# the helpers in bin/ (curl for UPDATE, ozma_say for the start-failure screen): an unzip on a PC can drop the x bit
chmod 0755 "$APP_DIR/bin/curl" "$APP_DIR/bin/ozma_say" 2>/dev/null
SD=${BT_SD_ROOT:-/mnt/SDCARD}   # BT_SD_ROOT: card root for scripts/emu/launcher_test.sh
BB=$SD/spruce/bin64/busybox; [ -x "$BB" ] || BB=busybox
# PLATFORM (platform/detect.sh, docs/research/all-devices/os/PLATFORM_LAYER_PLAN.md): which OS started us, which board, which
# chip, and from that what this launcher and the app may do there. It is the only place that knows OS and board names; it
# exports the BT_* switches that differ from the TrimUI Brick (none on the Brick under stock, spruce or Knulli: there the
# environment is exactly 0.9.1's) and writes nothing. A switch already set by the user or a test always wins.
#   L_LIB    folder put in front of the system libraries      L_PAUSE  services paused (SIGSTOP) while OZMA runs
#   L_IDLE   how the OS's idle dim / mute / sleep is held      L_FG     file(s) that name the running program for the OS
#   L_CLOCKS 1 = the A133 studio clock steps and thermal guard apply here
if [ -f "$APP_DIR/platform/detect.sh" ]; then
    OZMA_PLATFORM_DIR="$APP_DIR/platform"
    . "$APP_DIR/platform/detect.sh"
    # 0.9.1's one-word name for the OS (os.txt, studio.log, tests); the exact ids are in platform.txt
    case "$OZMA_OS" in knulli|batocera) OS=knulli ;; spruce) OS=spruce ;; nextui|minui) OS=nextui ;; *) OS=stock ;; esac
    L_LIB=${BT_LIB_PREPEND-}; L_PAUSE=${BT_PAUSE_SERVICES-}; L_IDLE=${BT_IDLE_INHIBIT:-none}; L_FG=${BT_FOREGROUND_FILE:-}
    L_CLOCKS=${BT_STUDIO_CLOCKS:-1}
else
    # no platform/ folder (a half-copied card): 0.9.1's own checks, so the Brick under stock, spruce and Knulli starts as before
    # Knulli (a Batocera-based OS for the Brick): OZMA is a port there, /userdata/roms/ports/OZMA.sh -> /userdata/OZMA/launch.sh
    KNULLI_MARK=${BT_KNULLI_MARK:-/usr/share/knulli/knulli.version}   # BT_KNULLI_MARK: tests only
    # (/usr/share/batocera: older Knulli releases, Batocera based too; neither exists on stock or spruce)
    if [ -f "$KNULLI_MARK" ] || { [ -z "${BT_KNULLI_MARK:-}" ] && [ -f /usr/share/batocera/batocera.version ]; }; then OS=knulli; elif [ -d "$SD/spruce" ]; then OS=spruce; elif [ -d "$SD/.system" ] && [ -d "$SD/Tools" ]; then OS=nextui; else OS=stock; fi
    L_LIB=/usr/trimui/lib; L_PAUSE="syncthing sftpgo smbd nmbd musicserver MtpDaemon"; L_IDLE=none; L_FG=""
    if [ "$OS" = knulli ]; then
        # - sound goes through PipeWire (no direct hw:audiocodec there); without this the graph runs 64-frame cycles
        export PIPEWIRE_LATENCY="${BT_PW_LATENCY:-256/48000}"
        # - SELECT+MENU (Knulli's dpad toggle) makes the D-pad arrive as the left stick: the app reads both
        export BT_STICK_AS_DPAD=1
        # - the codec belongs to PipeWire (volume keys, mute on sleep, headphones): always play through it, never hw: direct
        export BT_ALSA_DIRECT=0
        L_IDLE=knulli-pause
    fi
    # CPU: the studio clock steps and the thermal guard below are the Allwinner A133's (TrimUI Brick / Smart Pro). On another
    # chip (a hotter RK3566 idles near the guard's 55 C) they would hold it slow. No device tree to read = the Brick.
    L_CLOCKS=1
    DT_COMPAT=$({ tr '\0' ' ' < /proc/device-tree/compatible; } 2>/dev/null)
    case "$DT_COMPAT" in ""|*a133*|*sun50iw10*) ;; *) L_CLOCKS=0 ;; esac
fi
# YOUR OWN SAMPLES: <top of the card>/OZMA/Samples is the one place for a person's WAV files on every OS
# (platform/detect.sh says where the top is, in BT_USER_SAMPLES). The app shows it together with the old data/Samples
# as one library; nothing is ever moved or copied between the two. The folder is made here when it is missing, once,
# with a note inside; later OZMA writes nothing there. A card that cannot take it (read-only, full) or a launch without
# platform/: the variables are dropped and the app keeps to data/Samples alone.
if [ -n "${BT_USER_SAMPLES:-}" ] && [ ! -d "$BT_USER_SAMPLES" ]; then
    if mkdir -p "$BT_USER_SAMPLES" 2>/dev/null && [ -d "$BT_USER_SAMPLES" ]; then
        [ -f "$APP_DIR/platform/user_samples_note.txt" ] && cp "$APP_DIR/platform/user_samples_note.txt" "$BT_USER_SAMPLES/PUT YOUR WAV FILES HERE.txt" 2>/dev/null
    else
        US_FAILED=$BT_USER_SAMPLES; unset BT_USER_SAMPLES BT_SAMPLES_LABEL
    fi
fi
# TESTER REPORT: on an OS or board OZMA's own runs have not covered (platform status other than reference / tested:
# never the Brick under stock or spruce, never without platform/), a report a tester attaches to a bug post:
# App/OZMA/OZMA_REPORT_<board>_<os>.txt, rewritten after every run. platform/probe.sh (read-only) looks at the
# system once per new OS and board, here, before OZMA touches clocks, services or idle; nothing is sent anywhere.
# BT_REPORT=0 turns it off, BT_REPORT=1 writes it anywhere (a comparison from the Brick).
REPORT=""; PROBE=""
case "${BT_REPORT:-auto}" in
0) ;;
1) REPORT=1 ;;
*) case "${OZMA_STATUS:-reference}" in reference|tested) ;; *) REPORT=1 ;; esac ;;
esac
if [ -n "$REPORT" ]; then
    RID=$(printf '%s_%s' "${OZMA_BOARD:-unknown}" "${OZMA_OS:-unknown}" | tr -c 'A-Za-z0-9_.-' '-')
    REPORT="$APP_DIR/OZMA_REPORT_$RID.txt"; PROBE="$BT_DATA/probe_$RID.txt"
    if [ ! -s "$PROBE" ] && [ -f "$APP_DIR/platform/probe.sh" ]; then
        mkdir -p "$BT_DATA" 2>/dev/null; sh "$APP_DIR/platform/probe.sh" "$PROBE" >/dev/null 2>&1
    fi
    # install id: a random number made once on this card (never from the hardware), so two reports of one unit are
    # not counted as two units
    IID=$({ tr -cd '0-9a-f' < "$BT_DATA/install_id" | cut -c1-16; } 2>/dev/null)
    if [ -z "$IID" ]; then
        IID=$({ od -An -N8 -tx1 /dev/urandom | tr -cd '0-9a-f'; } 2>/dev/null)
        # an old BusyBox od knows none of those options: take hex digits straight from the random stream
        [ ${#IID} = 16 ] || IID=$({ LC_ALL=C tr -dc 'a-f0-9' < /dev/urandom | head -c 16; } 2>/dev/null)
        [ -n "$IID" ] && { mkdir -p "$BT_DATA"; printf '%s\n' "$IID" > "$BT_DATA/install_id"; } 2>/dev/null
    fi
fi
export LD_LIBRARY_PATH="$APP_DIR/lib${L_LIB:+:$L_LIB}${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
# IDLE: an OS that dims and MUTES after some minutes without a button press would silence a song playing hands-off.
# Held for the whole session, given back on exit (also on a crash or kill of the app, via the trap below).
IDLE_FILES=""; IDLE_OLD=""
case "$L_IDLE" in
knulli-pause)
    # Knulli's idle saver dims AND mutes after 5 min and suspends after 15 min; a *.pause file in /var/run/battery-saver
    # holds it while OZMA runs (KNULLI-ONLY, docs/knulli/STATUS.md)
    mkdir -p /var/run/battery-saver 2>/dev/null && : > /var/run/battery-saver/ozma.pause 2>/dev/null && IDLE_FILES=/var/run/battery-saver/ozma.pause ;;
muos-pid)
    # muOS mutes after 120 s idle (idle_mute) and may sleep; muhotkey holds both while the PID in these files is alive
    # (checked every 250 ms). This launcher's PID lives exactly as long as the session. Old contents go back on exit.
    for f in /run/muos/idle_game_inhibit /run/muos/idle_sleep_inhibit; do
        [ -d /run/muos ] || break
        IDLE_OLD="$IDLE_OLD$(cat "$f" 2>/dev/null | head -n1 | tr -cd '0-9')|"
        echo $$ > "$f" 2>/dev/null && IDLE_FILES="$IDLE_FILES $f"
    done ;;
esac
# FOREGROUND: the OS closes "the running program" by name (muOS: power off / sleep timeout send it SIGTERM, then SIGKILL
# after 3 s). Name bricktracker, so the app gets the SIGTERM and saves, not this shell. Only files the OS already has.
FG_DONE=""
for f in $(printf '%s' "$L_FG" | tr ',' ' '); do
    [ -f "$f" ] || continue
    o=$(head -n1 "$f" 2>/dev/null | tr -cd 'A-Za-z0-9._-'); echo bricktracker > "$f" 2>/dev/null && FG_DONE="$FG_DONE $f|$o"
done
SYS=/sys/devices/system/cpu
CPU=$SYS/cpu0/cpufreq
LOG="$APP_DIR/studio.log"
STUDIO=${BT_STUDIO:-1}
MINF=${BT_CPU_MIN_KHZ:-816000}
MAXF=${BT_CPU_MAX_KHZ:-}
log() { echo "$(date +%H:%M:%S) $*" >> "$LOG"; }
mode_of() { (stat -c %a "$1" || $BB stat -c %a "$1") 2>/dev/null; }
# spruce keeps these sysfs files read-only (chmod a-w) and itself does chmod/echo/chmod: same here
wr() { m=$(mode_of "$1"); chmod u+w "$1" 2>/dev/null; echo "$2" > "$1" 2>/dev/null; r=$?; [ -n "$m" ] && chmod "$m" "$1" 2>/dev/null; return $r; }
# a ceiling below the current floor needs the floor lowered first: the kernel refuses max < min (EINVAL), and spruce 4.6.0
# pins min = max = 1.8 GHz before every app, so without this the thermal guard could never lower the clock there
set_max() {
    lo=$(cat $CPU/scaling_min_freq 2>/dev/null)
    if [ -n "$lo" ] && [ "$lo" -gt "$1" ]; then
        f=$MINF; { [ "$f" = 0 ] || [ "$f" -gt "$1" ]; } && f=$1
        if wr $CPU/scaling_min_freq "$f"; then log "min $lo was above max $1 -> min $f"; else log "min $lo above max $1: lowering min to $f refused"; fi
    fi
    wr $CPU/scaling_max_freq "$1"
}

OLD_MIN=$(cat $CPU/scaling_min_freq 2>/dev/null)
OLD_MAX=$(cat $CPU/scaling_max_freq 2>/dev/null)
OLD_ON1=$(cat $SYS/cpu1/online 2>/dev/null); OLD_ON2=$(cat $SYS/cpu2/online 2>/dev/null)
# ceiling: 1608 MHz, or the user's own higher setting (never lower what spruce already allows)
if [ -z "$MAXF" ]; then MAXF=1608000; [ -n "$OLD_MAX" ] && [ "$OLD_MAX" -gt "$MAXF" ] && MAXF=$OLD_MAX; fi
# another chip: leave its clocks as its OS set them (BT_CPU_MIN_KHZ / BT_CPU_MAX_KHZ still apply when given)
[ "$L_CLOCKS" = 0 ] && [ -z "${BT_CPU_MIN_KHZ:-}" ] && MINF=0
[ "$L_CLOCKS" = 0 ] && [ -z "${BT_CPU_MAX_KHZ:-}" ] && MAXF=""
PAUSED=""; GUARD=""; WIFI_BLOCKED=0; IRQ_N=""; IRQ_OLD=""; USB_ON=0
# SPEAKER AUTO: the app flips the codec's speaker switch while headphones are in and puts it back on
# exit; this is the backstop for a crash or kill (amixer may be missing: then the app's own restore is all)
# (not where the speaker switch is not OZMA's to touch: BT_SPEAKER_CTL=0, e.g. a sound server owns the codec)
SPK_OLD=""
[ "${BT_SPEAKER_CTL:-1}" != 0 ] && SPK_OLD=$(command -v amixer >/dev/null 2>&1 && amixer -c 0 cget name='HpSpeaker Switch' 2>/dev/null | sed -n 's/.*: values=\([a-z,]*\).*/\1/p')
restore() {
    trap - EXIT INT TERM HUP
    [ -n "$GUARD" ] && kill $GUARD 2>/dev/null
    [ $USB_ON = 1 ] && "$APP_DIR/usb/usb_mode.sh" off >> "$LOG" 2>&1
    [ -n "$SPK_OLD" ] && amixer -c 0 cset name='HpSpeaker Switch' "$SPK_OLD" >/dev/null 2>&1
    for p in $PAUSED; do kill -CONT $p 2>/dev/null; done
    [ $WIFI_BLOCKED = 1 ] && rfkill unblock wifi 2>/dev/null
    [ -n "$IRQ_N" ] && [ -n "$IRQ_OLD" ] && echo "$IRQ_OLD" > /proc/irq/$IRQ_N/smp_affinity 2>/dev/null
    [ -n "$OLD_MAX" ] && wr $CPU/scaling_max_freq "$OLD_MAX"
    # max is back first, so the old floor fits under it again (also when set_max had to lower the floor)
    [ -n "$OLD_MIN" ] && { [ "$MINF" != 0 ] || [ "$(cat $CPU/scaling_min_freq 2>/dev/null)" != "$OLD_MIN" ]; } && wr $CPU/scaling_min_freq "$OLD_MIN"
    [ "$OLD_ON2" = 0 ] && wr $SYS/cpu2/online 0
    [ "$OLD_ON1" = 0 ] && wr $SYS/cpu1/online 0
    # the idle hold and the program name go back to what the OS had
    if [ "$L_IDLE" = knulli-pause ]; then [ -n "$IDLE_FILES" ] && rm -f $IDLE_FILES
    else rest=$IDLE_OLD; for f in $IDLE_FILES; do o=${rest%%|*}; rest=${rest#*|}; if [ -n "$o" ]; then echo "$o" > "$f"; else : > "$f"; fi; done 2>/dev/null; fi
    for x in $FG_DONE; do if [ -n "${x#*|}" ]; then echo "${x#*|}" > "${x%%|*}"; else : > "${x%%|*}"; fi; done 2>/dev/null
    [ "$STUDIO" = 1 ] && log "restored: cores online $(cat $SYS/online), min $(cat $CPU/scaling_min_freq) max $(cat $CPU/scaling_max_freq), resumed:${PAUSED:- none}"
}
trap restore EXIT INT TERM HUP

if [ "$MINF" != 0 ] && [ -n "$OLD_MIN" ] && [ "$OLD_MIN" -lt "$MINF" ]; then wr $CPU/scaling_min_freq "$MINF"; fi

if [ "$STUDIO" = 1 ]; then
    : > "$LOG"
    log "studio on ($OS, $APP_DIR): was cores $(cat $SYS/online), min $OLD_MIN max $OLD_MAX, $(cat /sys/class/thermal/thermal_zone0/temp) mC"
    [ "$OLD_ON1" = 0 ] && wr $SYS/cpu1/online 1
    [ "$OLD_ON2" = 0 ] && wr $SYS/cpu2/online 1
    [ -n "$MAXF" ] && set_max "$MAXF"
    [ "$L_CLOCKS" = 0 ] && log "not an A133 (${OZMA_SOC:-$DT_COMPAT}): clocks and thermal guard left to the OS"
    for name in $L_PAUSE; do
        for p in $(pidof $name 2>/dev/null); do kill -STOP $p 2>/dev/null && PAUSED="$PAUSED $p"; done
    done
    if [ "${BT_STUDIO_WIFI:-1}" = 0 ] && rfkill block wifi 2>/dev/null; then WIFI_BLOCKED=1; fi
    # R8 (BT_IRQ_AUDIO=1, test only until measured): the audio DMA interrupt goes to the audio core
    # (the last core, cpu3) instead of cpu0, so the DMA period IRQ wakes the audio thread locally
    if [ "${BT_IRQ_AUDIO:-0}" = 1 ]; then
        IRQ_N=$(grep -m1 'dma-controller' /proc/interrupts | cut -d: -f1 | tr -d ' ')
        if [ -n "$IRQ_N" ] && IRQ_OLD=$(cat /proc/irq/$IRQ_N/smp_affinity 2>/dev/null) && echo 8 > /proc/irq/$IRQ_N/smp_affinity 2>/dev/null; then
            log "irq $IRQ_N (dma) affinity $IRQ_OLD -> $(cat /proc/irq/$IRQ_N/smp_affinity)"
        else log "irq move failed (irq '$IRQ_N')"; IRQ_N=""; fi
    fi
    log "cores $(cat $SYS/online), max $(cat $CPU/scaling_max_freq), paused:${PAUSED:- none}, wifi blocked $WIFI_BLOCKED"
    # thermal guard: one OPP down at >= 55 C, back up at <= 50 C (checked every 2 s)
    MAIN=$$
    (
        STEPS="1008000 1200000 1416000 1608000 1800000 2000000"
        cap=$MAXF
        while sleep 2; do
            [ -d /proc/$MAIN ] || break   # launcher gone (killed): stop guarding
            # older spruce/PyUI may switch to Powersave mid-session (cpu1/2 offline, max 1488): undo it
            for c in 1 2; do
                if [ "$(cat $SYS/cpu$c/online 2>/dev/null)" = 0 ]; then wr $SYS/cpu$c/online 1; log "cpu$c went offline -> back online"; fi
            done
            [ -n "$MAXF" ] || continue   # another chip: only the cores above
            cur=$(cat $CPU/scaling_max_freq 2>/dev/null)
            [ -n "$cur" ] && [ "$cur" != "$cap" ] && { set_max "$cap"; log "max changed to $cur by someone -> $cap"; }
            cur=$(cat $CPU/scaling_min_freq 2>/dev/null)
            [ "$MINF" != 0 ] && [ -n "$cur" ] && [ "$cur" -lt "$MINF" ] && { wr $CPU/scaling_min_freq "$MINF"; log "min dropped to $cur -> $MINF"; }
            t=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null); t=${t:-0}
            new=$cap
            if [ "$t" -ge 55000 ]; then
                for s in $STEPS; do [ "$s" -lt "$cap" ] && new=$s; done
            elif [ "$t" -le 50000 ] && [ "$cap" -lt "$MAXF" ]; then
                for s in $STEPS; do [ "$s" -gt "$cap" ] && [ "$s" -le "$MAXF" ] && { new=$s; break; }; done
            fi
            if [ "$new" != "$cap" ]; then cap=$new; set_max "$cap"; log "thermal ${t} mC -> max $cap ($(cat $CPU/scaling_max_freq 2>/dev/null))"; fi
        done
    ) &
    GUARD=$!
fi
# USB HOST (top port, 08.11.2026): the built-in 4.9 snd-usb-audio gives devices with a UAC1 + a UAC2 control interface
# (Elektron Tonverk) MIDI only, no sound. usb/ozma_usb_audio.ko is the same driver with that fixed; loading it changes
# nothing by itself (every device stays on the built-in driver), the app moves only such devices to it on plug-in.
# Stays loaded after exit (harmless). Only on the exact kernel it was built for; BT_USB_HOSTFIX=0 skips it.
if [ "${BT_USB_HOSTFIX:-1}" != 0 ] && [ -f "$APP_DIR/usb/ozma_usb_audio.ko" ] && ! grep -q '^ozma_usb_audio ' /proc/modules \
   && [ "$(uname -r)" = 4.9.191 ] && [ "$(uname -v)" = "#860 SMP PREEMPT Wed Nov 26 03:43:02 UTC 2025" ]; then
    insmod "$APP_DIR/usb/ozma_usb_audio.ko" >> "$LOG" 2>&1 || echo "usb host: insmod ozma_usb_audio failed" >> "$LOG"
fi
# AUDIO > USB PC (the app writes $BT_DATA/io.cfg; BUFFER the app sets at run time); BT_USB_GADGET overrides it
if [ -z "$BT_USB_GADGET" ] && [ -f "$BT_DATA/io.cfg" ]; then
    case "$(awk '$1=="usb_pc"{print $2}' "$BT_DATA/io.cfg")" in 1) BT_USB_GADGET=out ;; 2) BT_USB_GADGET=in ;; esac
fi
case "${BT_USB_GADGET:-0}" in
out|in)
    if [ -x "$APP_DIR/usb/usb_mode.sh" ] && "$APP_DIR/usb/usb_mode.sh" on "$BT_USB_GADGET" >> "$LOG" 2>&1; then USB_ON=1; fi
    [ "$STUDIO" = 1 ] && log "usb device mode $BT_USB_GADGET: $([ $USB_ON = 1 ] && echo on || echo unavailable)" ;;
esac
{ echo "os $OS" > "$APP_DIR/os.txt"; } 2>/dev/null
# platform.txt: what platform/detect.sh found and set (os, board, chip, why, profiles), for bug reports and device runs
command -v ozma_platform_report >/dev/null 2>&1 && { ozma_platform_report > "$APP_DIR/platform.txt"; } 2>/dev/null
[ -n "${US_FAILED:-}" ] && { echo "samples: $US_FAILED could not be made (a read-only or full card?): the app keeps to data/Samples" >> "$APP_DIR/platform.txt"; } 2>/dev/null
# The app's log. A card the OS mounted read-only (FAT errors after a pull without eject) made "> log.txt" fail,
# and sh then skips the command: OZMA never started, no message anywhere. Now the log goes to /tmp instead.
OUT="$APP_DIR/log.txt"
(: >> "$OUT") 2>/dev/null || { OUT=/tmp/ozma-log.txt; (: >> "$OUT") 2>/dev/null || OUT=/dev/null; }
rm -f "$APP_DIR/START_FAILED.txt" 2>/dev/null
FAILED=""
./bricktracker --fullscreen "$@" > "$OUT" 2>&1
RC=$?
# The app could not start at all (another device or OS than the Brick's): say why in plain words next to it,
# instead of only going back to the menu. 126/127 = the system could not run the program; 1 = SDL (screen) failed.
if [ $RC = 126 ] || [ $RC = 127 ] || { [ $RC = 1 ] && grep -qE '^(SDL_Init|window):' "$OUT" 2>/dev/null; }; then
    WHY="the system could not start the program (code $RC)"
    if grep -q 'GLIBC_' "$OUT" 2>/dev/null; then WHY="this system's C library (glibc) is too old: OZMA needs $(grep -m1 -o 'GLIBC_[0-9.]*' "$OUT" | tr '_' ' ') (it is built for glibc 2.28)"
    elif grep -qE 'undefined symbol: SDL_|symbol lookup error.*SDL' "$OUT" 2>/dev/null; then WHY="this system's SDL2 library is too old for OZMA (it was built against SDL 2.30)"
    elif grep -q 'libSDL2' "$OUT" 2>/dev/null; then WHY="this system has no SDL2 library (libSDL2-2.0.so.0)"
    elif grep -q 'error while loading shared libraries' "$OUT" 2>/dev/null; then WHY="a system library is missing: $(grep -m1 -o 'libraries: [^:]*' "$OUT" | cut -c12-)"
    elif [ $RC = 126 ]; then WHY="bricktracker is not executable here (file permissions or a card mounted without exec)"
    elif [ $RC = 1 ]; then WHY="the screen could not be opened: $(grep -m1 -E '^(SDL_Init|window):' "$OUT")"
    elif [ ! -e /lib/ld-linux-aarch64.so.1 ]; then WHY="this system is not 64-bit ARM (aarch64 / arm64); OZMA needs a 64-bit ARM Linux"
    fi
    { { echo "OZMA could not start: $WHY."
        echo "OZMA is made for the TrimUI Brick (stock TrimUI OS, spruce; Knulli experimental). Other devices are untested."
        echo "Details: $OUT (uname: $(uname -srm 2>/dev/null))"; } > "$APP_DIR/START_FAILED.txt"; } 2>/dev/null
    { log "start failed (rc $RC): $WHY"; } 2>/dev/null
    FAILED=$WHY
fi
if [ -n "$REPORT" ]; then
    { {
        echo "OZMA TESTER REPORT - attach this file to your bug post (README.txt, REPORTING A BUG)."
        echo "Written on this device after every OZMA run; nothing was sent anywhere. No passwords, Wi-Fi settings, host"
        echo "name or serial numbers. Open it to see everything it holds. Song and sample names can appear in the log."
        echo "$(head -n1 "$APP_DIR/VERSION.txt" 2>/dev/null || echo 'OZMA (no VERSION.txt)'), run ended $(date -u '+%Y-%m-%d %H:%M UTC' 2>/dev/null) with code $RC${FAILED:+: $FAILED}"
        echo; echo "===== platform (what OZMA found and changed for this system)"; cat "$APP_DIR/platform.txt"
        [ -f "$BT_DATA/platform.override.env" ] && { echo "--- data/platform.override.env"; grep -v '^[[:space:]]*#' "$BT_DATA/platform.override.env"; }
        echo; echo "===== files (sha256 of what ran; one that differs from the published package = a changed build)"
        if command -v sha256sum >/dev/null 2>&1; then (cd "$APP_DIR" && sha256sum bricktracker launch.sh ozma_update.sh platform/detect.sh platform/boards.map)
        else echo "no sha256sum on this system"; fi
        echo "install id: ${IID:-none} (a random number kept in data/install_id, not made from the hardware)"
        echo; echo "===== start (from log.txt: screen, sound, real-time, power key, pad)"
        grep -m12 -E '^(# video=|video: |audio: |# audio thread |# power key|pad: )' "$OUT"
        echo; echo "===== log.txt (last 80 lines of this run)"; tail -n 80 "$OUT"
        echo; echo "===== sound sessions (data/audio_sessions.log, last 10: xruns = dropouts)"; tail -n 10 "$BT_DATA/audio_sessions.log"
        echo; echo "===== studio.log (last 30 lines)"; tail -n 30 "$LOG"
        echo; echo "===== system (platform/probe.sh, read-only, at the first start on this system)"; cat "$PROBE"
    } > "$REPORT"; } 2>/dev/null
fi
# UPDATE: 75 = INSTALL / ROLLBACK on the UPDATE page (saved, quit): start again, the boot step above does the rest.
# A new version that ends with an error while on trial starts again too: its third start rolls back by itself.
# 137 / 143 = killed from outside (SIGKILL / SIGTERM: spruce's 2 s power hold, an OS closing its apps): not a crash of
# the new version, so not counted towards a rollback (a crash ends in a signal of its own, like 134 abort or 139 segfault).
if [ -f "$APP_DIR/ozma_update.sh" ]; then
    AGAIN=0
    [ $RC = 75 ] && AGAIN=1
    if [ $RC != 0 ] && [ $RC != 75 ] && [ $RC != 137 ] && [ $RC != 143 ]; then sh "$APP_DIR/ozma_update.sh" crashed "$APP_DIR"; [ $? = 10 ] && AGAIN=1; fi
    if [ $AGAIN = 1 ]; then restore; exec sh "$APP_DIR/launch.sh" "$@"; fi
fi
# ...and on the screen too, for a few seconds (bin/ozma_say: static, needs only a framebuffer), so the player is not
# left with a black screen and then the menu again. Shown only when nothing starts again (an update trial rolls back first).
if [ -n "$FAILED" ] && [ -x "$APP_DIR/bin/ozma_say" ]; then
    SAY=/tmp/ozma-say.txt
    { printf 'OZMA could not start\n%s.\n\nOZMA is made for the TrimUI Brick. More in START_FAILED.txt in the OZMA folder.\n' "$FAILED" > "$SAY"; } 2>/dev/null \
        && "$APP_DIR/bin/ozma_say" -t 12 "$SAY" >/dev/null 2>&1
    rm -f "$SAY" 2>/dev/null
fi
exit $RC
