OZMA ON OTHER HANDHELDS - EXPERIMENTAL
======================================

OZMA is made for the TrimUI Brick. Everything in this folder is EXPERIMENTAL and UNTESTED on the devices named
here: it may not start, sound wrong, run slowly or show small text. No support is promised. Your songs stay in
App/OZMA/data.

What OZMA needs: a 64-bit ARM Linux handheld (aarch64), the system's SDL2 library and a screen. If one of these is
missing, OZMA says why on the screen and in App/OZMA/START_FAILED.txt.

TrimUI Smart Pro, TrimUI Brick Pro (stock OS, CrossMix, spruce, NextUI) - EXPERIMENTAL, untested
  Install exactly as on the Brick (unzip into the root of the card). OZMA appears in Apps (stock), in the App list
  (spruce) or in Tools (NextUI). USB audio / MIDI over the bottom port is for the Brick only.

TrimUI Smart Pro S, Miyoo Flip, Anbernic H700 consoles with NextUI or MinUI - EXPERIMENTAL, untested
  Install as on the Brick (unzip into the root of the card): OZMA appears in Tools (Tools/tg5050, my355, h700 or
  rg35xxplus). These entries use the system's own sound path and also read the stick as a D-pad.

Knulli - EXPERIMENTAL
  Use the separate OZMA Knulli zip and its README-KNULLI.txt.

muOS, ROCKNIX, ArkOS / dArkOS, AmberELEC and other systems with a Ports list - EXPERIMENTAL, untested
  1. Copy the App folder of the OZMA zip into the root of the card (so the card has App/OZMA).
  2. Copy OZMA.sh from this folder into the ports folder: muOS ROMS/Ports, ROCKNIX / AmberELEC roms/ports,
     ArkOS / dArkOS roms/ports or roms2/ports. Do not put it on a Brick card.
  3. Refresh the game list and start OZMA from Ports.
  If OZMA is not found, OZMA-NOT-FOUND.txt appears next to OZMA.sh and says what to do.

Buttons
  When PortMaster is installed, OZMA.sh passes its pad mapping for your device to OZMA. If the buttons still do
  nothing, OZMA asks you to press each button once ("PRESS UP", "PRESS A", ...) and remembers them in
  App/OZMA/data/pad_map.txt. Delete that file to teach the buttons again.

Tell us how it runs
  After every run OZMA writes a tester report into App/OZMA: a file whose name starts with OZMA_REPORT_ (your
  device and system follow). Attach it to your post (README.txt, REPORTING A BUG), with what you heard and saw.
  It is made on your device only and never sent anywhere; open it to see everything it holds.
  Small screens: if the text looks jagged, make a text file App/OZMA/data/platform.override.env with the line
  HW_SCALE_QUALITY=linear, start OZMA again and tell us which looks better (delete the file to go back).

Not possible from this zip: 32-bit systems (Miyoo Mini / A30 stock), Android handhelds.
