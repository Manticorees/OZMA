#!/bin/bash
# EXPERIMENTAL - untested on every device it is meant for. OZMA is made for the TrimUI Brick.
# A "Ports" entry for other handheld systems with PortMaster-style ports: copy THIS file into the ports folder,
#   muOS <card>/ROMS/Ports/OZMA.sh | ROCKNIX, AmberELEC /storage/roms/ports | ArkOS, dArkOS /roms/ports or /roms2/ports
# and keep the OZMA zip unpacked at the card root (App/OZMA). Never for the Brick (Apps/OZMA, App/OZMA, Knulli's
# OZMA.sh there). It only hands over to App/OZMA/launch.sh. bash, because PortMaster's control.txt is bash.
# App/OZMA is looked for in: $OZMA_APP, <here>/ozma (the PortMaster-format zip, scripts/ports/package.sh: the app
# beside this file, its songs in <here>/ozma-data, D9), <here>/../App/OZMA, <here>/../../App/OZMA, <here>/OZMA, then the usual card roots.
# With PortMaster: its per-device pad mapping (SDL_GAMECONTROLLERCONFIG) and its platform helper (on muOS it names the
# running program for the OS's close/sleep handling; no helper stops a menu). gptokeyb is never started: its
# SELECT+START exit would kill OZMA, and OZMA reads the pad itself. Without PortMaster: OZMA asks for each button once
# (PAD TEACH).
# Not found: OZMA-NOT-FOUND.txt next to this file.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
APP=""
for d in "${OZMA_APP:-}" "$HERE/ozma" "$HERE/../App/OZMA" "$HERE/../../App/OZMA" "$HERE/OZMA" /mnt/mmc/App/OZMA /mnt/sdcard/App/OZMA \
         /mnt/SDCARD/App/OZMA /storage/roms/App/OZMA /roms/App/OZMA /roms2/App/OZMA; do
    [ -n "$d" ] && [ -f "$d/launch.sh" ] && [ -f "$d/bricktracker" ] && { APP=$(CDPATH= cd -- "$d" && pwd); break; }
done
if [ -z "$APP" ]; then
    { echo "OZMA was not found. Unpack the OZMA zip into the root of this card (so App/OZMA exists), then start OZMA"
      echo "again. EXPERIMENTAL: OZMA is made for the TrimUI Brick and is untested on this device."; } > "$HERE/OZMA-NOT-FOUND.txt" 2>/dev/null
    exit 1
fi
# PortMaster (optional): its control.txt, the CFW module, the pad mapping for this device, the platform helpers
controlfolder=""
for c in /opt/system/Tools/PortMaster /opt/tools/PortMaster "${XDG_DATA_HOME:-$HOME/.local/share}/PortMaster" \
         /roms/ports/PortMaster /storage/roms/ports/PortMaster /mnt/mmc/MUOS/PortMaster /roms/tools/PortMaster \
         /mnt/SDCARD/Persistent/portmaster/PortMaster /mnt/SDCARD/Apps/PortMaster/PortMaster; do
    [ -f "$c/control.txt" ] && { controlfolder=$c; break; }
done
export OZMA_ENTRY=ports
if [ -n "$controlfolder" ]; then
    export OZMA_ENTRY=portmaster
    source "$controlfolder/control.txt" >/dev/null 2>&1
    [ -n "${CFW_NAME:-}" ] && [ -f "$controlfolder/mod_${CFW_NAME}.txt" ] && source "$controlfolder/mod_${CFW_NAME}.txt" >/dev/null 2>&1
    command -v get_controls >/dev/null 2>&1 && get_controls >/dev/null 2>&1
    [ -n "${sdl_controllerconfig:-}" ] && export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
    command -v pm_platform_helper >/dev/null 2>&1 && pm_platform_helper "$APP/bricktracker" >/dev/null 2>&1
fi
# App/OZMA/platform/detect.sh picks the settings for this device and OS (PipeWire or dmix, stick as D-pad, no sysfs
# writes, idle hold, ...). Without it (an App/OZMA from before the platform layer): not the Brick, so the system's own
# sound path (PipeWire / dmix), the stick also as a D-pad, clocks left to the OS.
if [ ! -f "$APP/platform/detect.sh" ]; then
    export BT_ALSA_DIRECT="${BT_ALSA_DIRECT:-0}" BT_STICK_AS_DPAD="${BT_STICK_AS_DPAD:-1}" BT_STUDIO="${BT_STUDIO:-0}"
    pidof pipewire >/dev/null 2>&1 && export PIPEWIRE_LATENCY="${PIPEWIRE_LATENCY:-256/48000}"
fi
# the card root for launch.sh's OS checks, when the app sits in <root>/App/OZMA
case "$APP" in */App/OZMA) [ -z "${BT_SD_ROOT:-}" ] && export BT_SD_ROOT="${APP%/App/OZMA}" ;; esac
# The ports package (its app folder holds port.json): songs and settings live BESIDE the app folder, in
# <here>/ozma-data (D9), because PortMaster's uninstall deletes every folder the port lists (OZMA.sh, ozma).
# An older OZMA folder that already has its own data/ (and no ozma-data/Songs yet) keeps it: no song is ever hidden.
if [ -z "${BT_DATA:-}" ] && [ -f "$APP/port.json" ]; then
    if [ -d "$APP/data" ] && [ ! -d "$HERE/ozma-data/Songs" ]; then export BT_DATA="$APP/data"
    else export BT_DATA="$HERE/ozma-data"; fi
fi
# YOUR OWN SAMPLES: a person's own samples go in OZMA/Samples beside the "ports" folder (the roms folder: the games card's top
# on a two-card system); where the ports folder is <card>/ROMS/Ports (muOS), at the top of that card. Only for the
# ports package; an App/OZMA at a card root finds its own card top in launch.sh.
if [ -z "${OZMA_CARD_TOP:-}" ] && [ -f "$APP/port.json" ]; then
    CT=$(CDPATH= cd -- "$HERE/.." 2>/dev/null && pwd)
    case "$CT" in ?*/ROMS) CT=${CT%/ROMS} ;; esac
    [ -n "$CT" ] && [ "$CT" != / ] && export OZMA_CARD_TOP="$CT"
fi
chmod 0755 "$APP/bricktracker" "$APP/launch.sh" 2>/dev/null   # exFAT / FAT: no exec bits after a copy
cd "$APP" || exit 1
sh ./launch.sh "$@"
RC=$?
command -v pm_finish >/dev/null 2>&1 && pm_finish >/dev/null 2>&1
exit $RC
