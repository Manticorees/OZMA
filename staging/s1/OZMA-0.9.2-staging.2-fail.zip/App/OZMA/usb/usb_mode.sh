#!/bin/sh
# usb_mode.sh - switch the Brick between its stock USB gadget (adb) and OZMA USB
# (class-compliant audio + MIDI, ozma_usb.ko). Everything it changes is put back by "off".
#
#   usb_mode.sh on [out|in|phone]   load ozma_usb.ko (default out = Brick plays into the host;
#                             out switches itself to the iPhone/iPad shape when an Apple host shows up;
#                             phone forces that shape: microphone terminal + volume unit)
#   usb_mode.sh off           unload it, give the UDC back to the stock gadget
#   usb_mode.sh status
#
# It does NOT touch the port role: the stock OTG manager switches USB0 to device mode by
# itself when a host (PC/Mac/iPad) powers the cable, which is when the UDC binds us.
# Never read usbc0/usb_device, usb_host or usb_null: on this kernel *reading* them switches
# the role and stops the automatic VBUS/ID scan until reboot.
#
# Exit codes: 0 ok, 3 kernel does not match the build (USB mode unavailable), 4 load failed.

DIR=$(cd "$(dirname "$0")" && pwd)
KO="$DIR/ozma_usb.ko"
STATE=/tmp/ozma_usb.state
G1=/sys/kernel/config/usb_gadget/g1
UDC_NAME=$(ls /sys/class/udc 2>/dev/null | head -1)
# The exact stock kernel the module is built for (TrimUI Brick firmware 1.1.1).
KREL="4.9.191"
KVER="#860 SMP PREEMPT Wed Nov 26 03:43:02 UTC 2025"
log() { echo "usb_mode: $*"; }

kernel_ok() {
	[ "$(uname -r)" = "$KREL" ] && [ "$(uname -v)" = "$KVER" ]
}

is_loaded() { grep -q '^ozma_usb ' /proc/modules; }

watchdogs() { # $1 = STOP or CONT; spruce's USB audio watchdog would grab our sound card
	for p in $(pgrep -f usb_audio_watchdog 2>/dev/null); do kill -"$1" "$p" 2>/dev/null; done
}

case "$1" in
on)
	MODE=${2:-out}
	[ "$MODE" = out ] || [ "$MODE" = in ] || [ "$MODE" = phone ] || { log "mode must be out, in or phone"; exit 2; }
	if ! kernel_ok; then
		log "kernel $(uname -r) $(uname -v) is not the one ozma_usb.ko was built for: USB mode off"
		exit 3
	fi
	[ -f "$KO" ] || { log "no $KO"; exit 4; }
	if is_loaded; then
		# (phone and out share the module mode "out"; always reload, the shape may differ)
		[ "$MODE" = in ] && [ "$(cat /sys/module/ozma_usb/parameters/mode 2>/dev/null)" = in ] && { log "already on (in)"; exit 0; }
		"$0" off
	fi
	OLD_UDC=$(cat $G1/UDC 2>/dev/null)
	echo "old_udc=$OLD_UDC" > $STATE
	watchdogs STOP
	# 0. freeze adbd first: when the UDC is freed it re-opens functionfs and the stock gadget g1
	#    re-takes the UDC within ~20 ms (test 1, 02.11); stopped before insmod it also cannot read
	#    functionfs mid-handover (13.11: garbage read size + page_alloc WARNING in adbd).
	#    SIGSTOP keeps its state; "off" resumes it.
	for p in $(pidof adbd); do kill -STOP "$p" && echo "adbd_stopped=$p" >> $STATE; done
	# 1. load first: with the UDC busy the gadget core parks us on its pending list
	# IN gets its own product id: with one id for both modes Windows reuses the OUT descriptors it cached and
	# makes no OZMA playback device for IN (Brick QA 0.8.2, 09.11: PID 0x0105 shows "Speakers (OZMA)" at once)
	# phone: own id too, so a PC that once saw it keeps its clean OUT device separate (Windows puts voice FX on mics)
	PID=0x0104; KMODE=$MODE; SHAPE=""
	[ "$MODE" = in ] && PID=0x0105
	[ "$MODE" = phone ] && { PID=0x0106; KMODE=out; SHAPE="shape=2"; }
	# OZMA_USB_EXTRA: extra module params for host-compatibility tests (e.g. "iad=0 fu=1 it_mic=1")
	# speed: full by default (phones/tablets need it); OZMA_USB_SPEED=high brings back the old 0.9 behaviour
	SPEED=${OZMA_USB_SPEED:-full}
	# high = the exact 0.9 device: high speed, 500 mA, line-in terminal, no Feature Unit
	[ "$SPEED" = high ] && SHAPE="shape=1 max_power=500 fu=0 it_mic=0 bcdDevice=0x0001"
	if ! insmod "$KO" mode="$KMODE" idProduct="$PID" speed="$SPEED" $SHAPE ${OZMA_USB_DEBUG:+debug=1} $OZMA_USB_EXTRA; then
		log "insmod failed"
		for p in $(sed -n 's/^adbd_stopped=//p' $STATE); do kill -CONT "$p" 2>/dev/null; done
		watchdogs CONT; rm -f $STATE; exit 4
	fi
	# 3. free the UDC: unregistering g1 makes the core bind the next pending driver (us) at once
	[ -n "$OLD_UDC" ] && echo "" > $G1/UDC 2>/dev/null
	i=0; while [ "$(sed -n 's/^USB_UDC_DRIVER=//p' /sys/class/udc/$UDC_NAME/uevent 2>/dev/null)" != "ozma_usb" ] && [ $i -lt 20 ]; do sleep 0.1; i=$((i+1)); done
	if [ "$(sed -n 's/^USB_UDC_DRIVER=//p' /sys/class/udc/$UDC_NAME/uevent 2>/dev/null)" != "ozma_usb" ]; then
		log "ozma_usb did not get the UDC (function=$(sed -n 's/^USB_UDC_DRIVER=//p' /sys/class/udc/$UDC_NAME/uevent 2>/dev/null)), restoring"
		"$0" off; exit 4
	fi
	# wait for the misc device node (mdev/udev)
	i=0; while [ ! -e /dev/ozma_usb ] && [ $i -lt 20 ]; do sleep 0.1; i=$((i+1)); done
	if [ ! -e /dev/ozma_usb ]; then
		MINOR=$(awk '$2=="ozma_usb"{print $1}' /proc/misc)
		[ -n "$MINOR" ] && mknod /dev/ozma_usb c 10 "$MINOR" && chmod 666 /dev/ozma_usb
	fi
	log "on ($MODE), udc $UDC_NAME state $(cat /sys/class/udc/$UDC_NAME/state 2>/dev/null)"
	;;
off)
	if is_loaded; then
		rmmod ozma_usb || { log "rmmod failed (device busy? close the app first)"; exit 4; }
	fi
	OLD_UDC=""; ADBD=""
	if [ -f $STATE ]; then
		OLD_UDC=$(sed -n 's/^old_udc=//p' $STATE)
		ADBD=$(sed -n 's/^adbd_stopped=//p' $STATE)
	fi
	[ -n "$OLD_UDC" ] && [ -z "$(cat $G1/UDC 2>/dev/null)" ] && echo "$OLD_UDC" > $G1/UDC 2>/dev/null
	for p in $ADBD; do kill -CONT "$p" 2>/dev/null; done
	watchdogs CONT
	rm -f $STATE
	log "off, stock gadget on '$(cat $G1/UDC 2>/dev/null)'"
	;;
status)
	if is_loaded; then
		log "on, mode $(cat /sys/module/ozma_usb/parameters/mode), udc $UDC_NAME $(cat /sys/class/udc/$UDC_NAME/state 2>/dev/null), role $(cat /sys/devices/platform/soc/usbc0/otg_role 2>/dev/null)"
	else
		log "off, kernel match: $(kernel_ok && echo yes || echo no), role $(cat /sys/devices/platform/soc/usbc0/otg_role 2>/dev/null)"
	fi
	;;
*)
	echo "usage: $0 on [out|in] | off | status"; exit 2 ;;
esac
