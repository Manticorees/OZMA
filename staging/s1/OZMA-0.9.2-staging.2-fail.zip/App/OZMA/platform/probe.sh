#!/bin/sh
# OZMA device probe (2026-11-13). READ-ONLY: it changes nothing on the device. Shipped as App/OZMA/platform/probe.sh.
# It only reads files and runs listing commands, then writes ONE text file. No modprobe, no mixer changes, no network,
# no passwords: Wi-Fi config files and the environment are never read; the host name, serial numbers, MAC addresses
# and device ids are left out (uname without the host name, /proc/cmdline without serial / mac / uuid tokens,
# input devices without Uniq, no /dev/input/by-id).
#
#   sh probe.sh OUT     write to OUT (launch.sh: once per new OS and board, into the tester report, see README.md)
#   sh probe.sh         by hand from a terminal or file manager: ozma_probe_<date>.txt next to itself (or in /tmp)
# What each section answers: docs/research/all-devices/hardware/PROBE.md.
# POSIX sh only (busybox ash, dash, bash). Each command is optional: a missing tool prints "(none)".

LC_ALL=C; export LC_ALL
if [ -n "${1:-}" ]; then out=$1; ( : > "$out" ) 2>/dev/null || { echo "cannot write $out"; exit 1; }
else
    here=$(cd "$(dirname "$0")" 2>/dev/null && pwd) || here=/tmp
    stamp=$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)
    out="$here/ozma_probe_${stamp}.txt"
    ( : > "$out" ) 2>/dev/null || out="/tmp/ozma_probe_${stamp}.txt"
    ( : > "$out" ) 2>/dev/null || { echo "cannot write a result file"; exit 1; }
fi

sec() { printf '\n===== %s\n' "$1" >> "$out"; }
show() { # show FILE [max lines]
    if [ -r "$1" ]; then printf -- '--- %s\n' "$1" >> "$out"; head -n "${2:-80}" "$1" 2>/dev/null | tr -d '\000' >> "$out"; echo >> "$out"
    else printf -- '--- %s (none)\n' "$1" >> "$out"; fi
}
run() { # run "label" command...  (stdout+stderr, 120 lines max)
    l=$1; shift
    if command -v "$1" >/dev/null 2>&1; then printf -- '--- $ %s\n' "$l" >> "$out"; "$@" 2>&1 | head -n 120 >> "$out"
    else printf -- '--- $ %s (none)\n' "$l" >> "$out"; fi
}
strs() { # printable strings of a binary that match a pattern, without needing 'strings'
    [ -r "$1" ] || { printf -- '--- %s (none)\n' "$1" >> "$out"; return; }
    printf -- '--- strings %s | grep %s\n' "$1" "$2" >> "$out"
    if command -v strings >/dev/null 2>&1; then strings "$1" 2>/dev/null | grep -E "$2" | sort -u | head -20 >> "$out"
    else tr -c '[:print:]' '\n' < "$1" 2>/dev/null | grep -E "$2" | sort -u | head -20 >> "$out"; fi
}

echo "OZMA device probe 2 $(date 2>/dev/null)" > "$out"

sec "1 system"
run "uname -srvm" uname -srvm
show /etc/os-release 20
show /proc/version
show /proc/device-tree/model
if [ -r /proc/device-tree/compatible ]; then printf -- '--- /proc/device-tree/compatible\n%s\n' "$(tr '\000' ' ' < /proc/device-tree/compatible)" >> "$out"; fi
if [ -r /proc/cmdline ]; then   # boot options without anything that names this unit
    printf -- '--- /proc/cmdline (serial, mac, uuid, id tokens left out)\n' >> "$out"
    tr ' ' '\n' < /proc/cmdline | grep -viE 'serial|mac|uuid|[^a-z]id=|^id=|sn=|wifi|bt_addr' | tr '\n' ' ' >> "$out"; echo >> "$out"
fi

sec "2 which OS (marker files, the same ones scripts/platform/detect.sh reads)"
strs /usr/trimui/bin/MainUI '^Trimui'
strs /mnt/vendor/bin/dmenu.bin '^RG'
for f in /opt/muos/device/config/board/name /opt/muos/config/system/version /opt/muos/config/system/build /boot/boot/batocera.board /boot/boot/knulli.board /boot/boot/batocera.board.capability \
         /usr/share/knulli/knulli.version /usr/share/batocera/batocera.version /usr/magicx/device /tmp/spruce_device_info.env \
         /mnt/SDCARD/spruce/spruce /storage/.config/device /etc/rocknix-release /usr/share/plymouth/themes/text.plymouth \
         /etc/arkos-release /usr/share/ark_version /usr/share/darkos-release; do
    [ -e "$f" ] && show "$f" 10
done
printf -- '--- selected env: IS_NEXT=%s PLATFORM=%s DEVICE=%s SDL_GAMECONTROLLERCONFIG_FILE=%s\n' \
    "${IS_NEXT:-}" "${PLATFORM:-}" "${DEVICE:-}" "${SDL_GAMECONTROLLERCONFIG_FILE:-}" >> "$out"
printf -- '--- running programs (names only, no arguments)\n' >> "$out"
for p in /proc/[0-9]*; do cat "$p/comm" 2>/dev/null; done | sort | uniq -c | sort -rn | head -n 80 >> "$out"
sec "3 CPU and memory"
grep -E '^(Hardware|model name|CPU part|CPU implementer|Features)' /proc/cpuinfo 2>/dev/null | sort | uniq -c >> "$out"
run "nproc" nproc
for p in /sys/devices/system/cpu/cpu0/cpufreq /sys/devices/system/cpu/cpufreq/policy0 /sys/devices/system/cpu/cpufreq/policy4; do
    [ -d "$p" ] || continue
    for f in scaling_governor scaling_available_governors scaling_available_frequencies scaling_min_freq scaling_max_freq cpuinfo_max_freq; do
        [ -r "$p/$f" ] && printf '%s/%s: %s\n' "$p" "$f" "$(cat "$p/$f")" >> "$out"
    done
done
grep -E '^(MemTotal|MemFree|MemAvailable|SwapTotal|Cached):' /proc/meminfo >> "$out" 2>/dev/null

sec "4 display"
for f in /sys/class/graphics/fb0/virtual_size /sys/class/graphics/fb0/modes /sys/class/graphics/fb0/bits_per_pixel /sys/class/graphics/fb0/rotate \
         /sys/class/disp/disp/attr/sys; do [ -r "$f" ] && show "$f" 20; done
for d in /sys/class/drm/card*-*; do [ -d "$d" ] && printf '%s: %s %s\n' "$d" "$(cat "$d/status" 2>/dev/null)" "$(head -n 3 "$d/modes" 2>/dev/null | tr '\n' ' ')" >> "$out"; done
ls -l /dev/fb* /dev/dri 2>/dev/null >> "$out"

sec "5 audio"
show /proc/asound/cards
show /proc/asound/pcm
show /proc/asound/devices 40
for c in /proc/asound/card[0-9]*; do
    [ -d "$c" ] || continue
    n=${c##*card}
    run "amixer -c $n controls" amixer -c "$n" controls
    for s in "$c"/pcm*p/info; do [ -r "$s" ] && show "$s" 20; done
done
show /etc/asound.conf 60
show "$HOME/.asoundrc" 60
run "pipewire / pulse / wireplumber running" sh -c 'pidof pipewire pipewire-pulse wireplumber pulseaudio 2>/dev/null; echo "(pids above, empty = none)"'
for f in /usr/share/pipewire/pipewire.conf /etc/pipewire/pipewire.conf /opt/muos/share/conf/pipewire.conf; do
    [ -r "$f" ] && { printf -- '--- %s (clock and quantum lines)\n' "$f" >> "$out"; grep -E 'clock\.|quantum' "$f" | head -20 >> "$out"; }
done

sec "6 input (buttons, sticks)"
if [ -r /proc/bus/input/devices ]; then   # without U: Uniq= (a Bluetooth pad's address)
    printf -- '--- /proc/bus/input/devices (Uniq left out)\n' >> "$out"; grep -v '^U: ' /proc/bus/input/devices | head -n 200 >> "$out"
fi
ls -l /dev/input 2>/dev/null >> "$out"
show /opt/muos/device/config/board/sdl_map 5
for f in /usr/lib/gamecontrollerdb.txt /usr/share/SDL2/gamecontrollerdb.txt /mnt/SDCARD/.system/*/gamecontrollerdb.txt /storage/.config/SDL-GameControllerDB/gamecontrollerdb.txt; do
    [ -r "$f" ] && printf -- '--- %s: %s lines (not copied)\n' "$f" "$(wc -l < "$f")" >> "$out"
done

sec "7 USB"
ls /sys/class/udc 2>/dev/null | sed 's/^/udc: /' >> "$out"
for f in /sys/devices/platform/soc/usbc0/otg_role /sys/devices/platform/soc/usbc0/usb_host /sys/devices/platform/soc/usbc0/usb_device; do [ -r "$f" ] && show "$f" 5; done
[ -d /sys/kernel/config/usb_gadget ] && echo "configfs usb_gadget: present" >> "$out" || echo "configfs usb_gadget: not mounted or absent" >> "$out"
for d in /sys/bus/usb/devices/*; do [ -r "$d/product" ] && printf '%s: %s %s:%s\n' "${d##*/}" "$(cat "$d/product")" "$(cat "$d/idVendor" 2>/dev/null)" "$(cat "$d/idProduct" 2>/dev/null)" >> "$out"; done
if [ -r /proc/config.gz ] && command -v zcat >/dev/null 2>&1; then
    printf -- '--- /proc/config.gz (USB gadget and sound options)\n' >> "$out"
    zcat /proc/config.gz | grep -E 'CONFIG_USB_(CONFIGFS|F_|G_|LIBCOMPOSITE|MUSB|DWC|SUNXI)|CONFIG_SND_USB_AUDIO|CONFIG_SND_(SOC_)?(RK817|ES8388|SUN)' | head -60 >> "$out"
fi
run "lsmod" lsmod

sec "8 network"
for n in /sys/class/net/*; do [ -d "$n" ] && printf '%s: %s %s\n' "${n##*/}" "$(cat "$n/operstate" 2>/dev/null)" "$(readlink "$n/device/driver" 2>/dev/null | sed 's#.*/##')" >> "$out"; done
run "rfkill list" rfkill list

sec "9 libraries (SDL, glibc, ALSA, curl)"
for d in /usr/lib /usr/lib64 /usr/lib/aarch64-linux-gnu /lib /lib/aarch64-linux-gnu /usr/trimui/lib /mnt/SDCARD/.system/*/lib; do
    [ -d "$d" ] && ls -l "$d" 2>/dev/null | grep -E 'libSDL2|libasound|libc\.so|libc-|ld-linux|libcurl|libpipewire' >> "$out"
done
run "ldd --version" ldd --version
run "which curl wget amixer aplay strings" sh -c 'for t in curl wget amixer aplay strings; do printf "%s: %s\n" "$t" "$(command -v $t)"; done'

sec "10 storage"
run "df -h" df -h
mount 2>/dev/null | grep -E 'mmc|sd[a-z]|SDCARD|roms|userdata|share|storage' >> "$out"

echo >> "$out"; echo "end of probe" >> "$out"
echo "probe written: $out"
exit 0
