# OZMA platform detection + profile resolve (docs/research/all-devices/os/PLATFORM_LAYER_PLAN.md step 1). Shipped as
# App/OZMA/platform/detect.sh and sourced by launch.sh, never executed; POSIX sh (BusyBox ash, dash, bash).
#
# This is the ONLY place that knows OS and board names. It answers three separate questions and never mixes them:
#   OZMA_OS     which firmware runs us      (ids: docs/research/all-devices/README.md)
#   OZMA_BOARD  which hardware              (ids: docs/research/all-devices/hardware/devices.json, via boards.map)
#   OZMA_SOC    which chip family           (a133 h700 a523 rk3566 rk3326 sm8250 other)
# then reads two kinds of profile and RESOLVES them into the BT_* switches the app and launch.sh already read:
#   hardware profiles (hw/soc-*.env, hw/board-*.env) say what the hardware CAN do      (HW_* keys)
#   OS profiles       (os/<id>.env)                  say what the OS ALLOWS / needs   (OS_* keys)
#   BT_ALSA_DIRECT=auto only when the OS allows direct ALSA AND the board has the proven codec, and so on.
# So no profile order can switch a PipeWire OS to direct ALSA by accident.
#
# Rules: no bash-only syntax; tr only with spelled-out ranges (BusyBox tr on the Brick reads [:upper:] literally);
# every probe may fail silently; anything unclear ends in the safe profile, never in a stop. A BT_* / PIPEWIRE_*
# variable already set when launch.sh started (a user's setting, a test) is never overridden.
#
# Inputs (tests): BT_ROOT = fake system root prefix, BT_SD_ROOT = card root, BT_KNULLI_MARK (legacy hook), BT_NO_STRINGS,
# OZMA_PLATFORM_DIR = folder with boards.map and profiles/ (default: this file's folder via APP_DIR/platform).
# Inputs (from the entry file / parent): OZMA_ENTRY (apps|app|pak|ports|portmaster|muos-app|knulli-port),
# OZMA_CARD_TOP (the folder a person sees as the top of the card, where the entry file knows its own layout),
# IS_NEXT, PLATFORM, DEVICE (NextUI), SYSTEM_PATH (MinUI), CFW_NAME, DEVICE_NAME (PortMaster control.txt, when sourced
# before us). Sources of every marker: docs/research/all-devices/os/OS_MATRIX.md and os/research/*.md.

R=${BT_ROOT:-}
SD=${BT_SD_ROOT:-/mnt/SDCARD}
OZMA_PD=${OZMA_PLATFORM_DIR:-${APP_DIR:-.}/platform}
OZMA_WHY=""
OZMA_ENV0=" $(env 2>/dev/null | sed -n 's/^\([A-Za-z_][A-Za-z0-9_]*\)=.*/\1/p' | tr '\n' ' ') "

ozma_why() { OZMA_WHY="${OZMA_WHY:+$OZMA_WHY; }$*"; }
ozma_lc() { tr 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' 'abcdefghijklmnopqrstuvwxyz'; }
ozma_line1() { for f in "$@"; do [ -f "$f" ] && { sed -n '1{s/[^A-Za-z0-9 ._-]//g;p;}' "$f" 2>/dev/null; return 0; }; done; return 1; }
# printable runs of a binary file, first line starting with $2 (like `strings f | grep -m1 ^$2`)
ozma_strings1() {
    [ -f "$1" ] || return 1
    if [ -z "${BT_NO_STRINGS:-}" ] && command -v strings >/dev/null 2>&1; then strings "$1" 2>/dev/null
    else tr -c 'A-Za-z0-9 ._-' '\n' < "$1" 2>/dev/null; fi | sed -n "/^$2/{p;q;}"
}
ozma_has() { grep -qi "$1" "$2" 2>/dev/null; }

# ------------------------------------------------------------------ OS
# 1. what the parent told us, or a tmpfs file the running OS wrote at this boot (strongest: that OS really ran us)
# 2. own-distro markers on the rootfs (the OS owns /, so these cannot be leftovers)
# 3. overlay markers on the card (spruce, NextUI/MinUI, CrossMix), constrained by the entry kind
# 4. the vendor base (TrimUI, Anbernic, Miyoo stock)
OSREL="$R/etc/os-release"
PLYM=$(sed -n 's/^title=//p' "$R/usr/share/plymouth/themes/text.plymouth" 2>/dev/null | head -n1)
KNULLI_MARK=${BT_KNULLI_MARK:-$R/usr/share/knulli/knulli.version}
OZMA_OS=""
# MinUI exports PLATFORM=<tg5040|my355|rg35xxplus> and SYSTEM_PATH=<card>/.system/<PLATFORM>, never IS_NEXT. spruce
# also exports PLATFORM (Brick, SmartPro, Flip...) with another meaning: PLATFORM alone never names an OS.
MINUI_ENV=0
case "${SYSTEM_PATH:-}" in */.system/"${PLATFORM:-/}") MINUI_ENV=1 ;; esac
if [ "${IS_NEXT:-}" = yes ]; then OZMA_OS=nextui; ozma_why "env IS_NEXT=yes"
elif [ -f "$R/tmp/spruce_device_info.env" ]; then OZMA_OS=spruce; ozma_why "/tmp/spruce_device_info.env (written by spruce at this boot)"
elif [ $MINUI_ENV = 1 ]; then OZMA_OS=minui; ozma_why "env SYSTEM_PATH=.system/\$PLATFORM, no IS_NEXT"
elif [ -f "$R/etc/rocknix-release" ] || ozma_has 'rocknix' "$OSREL"; then OZMA_OS=rocknix; ozma_why "os-release rocknix"
elif [ -f "$R/etc/jelos-release" ] || ozma_has 'os_name="\{0,1\}jelos' "$OSREL" || ozma_has 'unofficialos' "$OSREL"; then OZMA_OS=rocknix; ozma_why "JELOS family (rocknix profile)"
elif [ -d "$R/opt/muos" ]; then OZMA_OS=muos; ozma_why "/opt/muos"
elif [ -f "$KNULLI_MARK" ] || { [ -z "${BT_KNULLI_MARK:-}" ] && { [ -f "$R/boot/boot/knulli.board" ] || [ -f "$R/etc/knulli.version" ]; }; }; then OZMA_OS=knulli; ozma_why "knulli marker"
elif [ -f "$R/usr/share/batocera/batocera.version" ]; then OZMA_OS=batocera; ozma_why "batocera.version, no knulli marker"
elif [ -n "$PLYM" ]; then
    case "$(printf '%s' "$PLYM" | ozma_lc)" in
        *darkosre*|*darkos*) OZMA_OS=darkos ;;
        *arkos*) OZMA_OS=arkos ;;
        *thera*|*"the r.a"*|*retrooz*) OZMA_OS=arkos-clone ;;
    esac
    [ -n "$OZMA_OS" ] && ozma_why "plymouth title '$PLYM'"
fi
if [ -z "$OZMA_OS" ]; then
    if [ -f "$R/etc/darkos_version" ]; then OZMA_OS=darkos; ozma_why "/etc/darkos_version"
    elif [ -f "$R/etc/arkos_version" ]; then OZMA_OS=arkos; ozma_why "/etc/arkos_version"
    elif [ -f "$R/etc/amber_version" ] || [ -f "$R/etc/amberelec_version" ]; then OZMA_OS=amberelec; ozma_why "amberelec version file"
    fi
fi
# overlay OSes on the card. The entry kind narrows them: the stock Apps menu cannot be spruce or NextUI.
if [ -z "$OZMA_OS" ]; then
    case "${OZMA_ENTRY:-}" in
        apps) ;;   # TrimUI stock / CrossMix menu: a spruce/ or .system/ folder on this card is a leftover
        *)
            # older spruce (before the tmpfs info file) is only seen by its card folder; weak: it stays after a switch to stock
            if [ -f "$SD/spruce/spruce" ] || { [ "${OZMA_ENTRY:-}" != pak ] && [ -d "$SD/spruce" ]; }; then
                OZMA_OS=spruce; ozma_why "spruce folder on the card (weak marker)"
            elif ls "$SD"/.system/*/bin/nextui.elf >/dev/null 2>&1; then OZMA_OS=nextui; ozma_why "nextui.elf on the card (no IS_NEXT)"
            elif ls "$SD"/.system/*/bin/minui.elf >/dev/null 2>&1 || { [ -n "${PLATFORM:-}" ] && [ -d "$SD/.system/$PLATFORM" ]; }; then OZMA_OS=minui; ozma_why "MinUI .system on the card"
            elif [ "${OZMA_ENTRY:-}" = pak ] && [ -d "$SD/.system" ]; then OZMA_OS=minui; ozma_why "pak entry + .system"
            fi ;;
    esac
fi
if [ -z "$OZMA_OS" ]; then
    if [ -d "$R/usr/trimui" ]; then
        if [ -f "$SD/System/etc/ex_config" ]; then OZMA_OS=crossmix; ozma_why "TrimUI + CrossMix System/etc/ex_config"
        else OZMA_OS=trimui-stock; ozma_why "/usr/trimui"; fi
    elif [ -f "$R/mnt/vendor/bin/dmenu.bin" ]; then OZMA_OS=anbernic-stock; ozma_why "/mnt/vendor/bin/dmenu.bin"
    elif [ -d "$R/usr/miyoo" ]; then OZMA_OS=miyoo-stock; ozma_why "/usr/miyoo"
    fi
fi

# ------------------------------------------------------------------ SoC (device tree "compatible")
OZMA_DT=$({ tr '\0' ' ' < "$R/proc/device-tree/compatible"; } 2>/dev/null)
case "$OZMA_DT" in
    ""|*a133*|*sun50iw10*) OZMA_SOC=a133 ;;   # no device tree = the Brick, as launch.sh does today
    *h700*|*sun50iw9*|*h616*|*h618*) OZMA_SOC=h700 ;;
    *a523*|*a527*|*t527*|*sun55iw3*) OZMA_SOC=a523 ;;
    *rk3566*|*rk3568*) OZMA_SOC=rk3566 ;;
    *rk3326*|*px30*) OZMA_SOC=rk3326 ;;
    *qcom*|*sm8250*|*sm8550*|*sm8650*) OZMA_SOC=sm8250 ;;
    *) OZMA_SOC=other ;;
esac
# no marker at all on the Brick's chip = stock, as launch.sh does today; anything else unknown
if [ -z "$OZMA_OS" ]; then
    if [ "$OZMA_SOC" = a133 ] && [ -z "$OZMA_DT" ]; then OZMA_OS=trimui-stock; ozma_why "no markers, no device tree (Brick default)"
    else OZMA_OS=unknown; ozma_why "no OS marker"; fi
fi

# ------------------------------------------------------------------ board: a name from each source in turn, through boards.map
# The first name boards.map knows is the board. A name it does not know (a new spruce platform word, a board file of a
# new OS build) does not end the search: the next source may still say plainly what the hardware is. The report keeps
# every name that was tried; with no known name, OZMA_BOARD_RAW is the best source's own.
OZMA_BOARD=""; OZMA_BOARD_RAW=""; NAMED=""
ozma_board_try() { # $1 source, $2 the raw name it gave (may be empty)
    [ -n "$2" ] && [ -z "$OZMA_BOARD" ] || return 0
    [ -n "$NAMED" ] || OZMA_BOARD_RAW="$1:$2"
    NAMED=1
    OZMA_BOARD=$(awk -v k="$1:$2" 'substr($0,1,1)!="#" && NF>=2 { id=$NF; $NF=""; sub(/[ \t]+$/,""); if ($0==k) { print id; exit } }' "$OZMA_PD/boards.map" 2>/dev/null)
    [ -n "$OZMA_BOARD" ] && OZMA_BOARD_RAW="$1:$2"
    ozma_why "board $1:$2 -> ${OZMA_BOARD:-unmapped}"
}
[ "$OZMA_OS" = nextui ] && ozma_board_try nextui "${DEVICE:-}"
[ -z "$OZMA_BOARD" ] && ozma_board_try knulli "$(ozma_line1 "$R/boot/boot/knulli.board" "$R/boot/boot/batocera.board" "$R/boot/knulli.board" "$R/boot/batocera.board")"
[ -z "$OZMA_BOARD" ] && ozma_board_try muos "$(ozma_line1 "$R/opt/muos/device/config/board/name" "$R/opt/muos/config/device.txt")"
[ -z "$OZMA_BOARD" ] && [ -f "$R/tmp/spruce_device_info.env" ] && ozma_board_try spruce "$(sed -n 's/^\(export \)\{0,1\}SPRUCE_PLATFORM=//p' "$R/tmp/spruce_device_info.env" | tr -d "\"'\r" | head -n1)"
ARKHOME=$R/home   # ArkOS user "ark" (written this way so the release gate's machine-path scan stays quiet)
[ -z "$OZMA_BOARD" ] && ozma_board_try arkos "$(ozma_line1 "$ARKHOME/ark/.config/.DEVICE")"
# TrimUI boards on the vendor kernel (stock, spruce, NextUI, MinUI, CrossMix): /proc/cpuinfo "Hardware" says TG3040 etc.
[ -z "$OZMA_BOARD" ] && ozma_board_try cpuinfo "$(sed -n 's/.*\(TG[0-9]0[0-9]0\).*/\1/p' "$R/proc/cpuinfo" 2>/dev/null | head -n1)"
# spruce's own A133P base (oakMOSS) and MagicX firmware: no TG string, no stock MainUI
[ -z "$OZMA_BOARD" ] && ozma_board_try magicx "$(ozma_line1 "$R/usr/magicx/device")"
[ -z "$OZMA_BOARD" ] && ozma_board_try trimui-mainui "$(ozma_strings1 "$R/usr/trimui/bin/MainUI" 'Trimui')"
[ -z "$OZMA_BOARD" ] && ozma_board_try anbernic-dmenu "$(ozma_strings1 "$R/mnt/vendor/bin/dmenu.bin" 'RG')"
# mainline kernels (ROCKNIX, Batocera): the device-tree "compatible" list names the board, the most exact name first
# (lower-cased here). Every name is asked in turn: ROCKNIX's R36S tree says "gameconsole,r35s" before
# "gameconsole,r36s" (read from its 20261101 image). An entry from a chip vendor (allwinner, rockchip, arm, qcom) says
# only the SoC: a BSP kernel has nothing else.
if [ -z "$OZMA_BOARD" ]; then
    for c in $({ tr '\0' '\n' < "$R/proc/device-tree/compatible"; } 2>/dev/null | ozma_lc | tr -d '*?[] \t'); do
        case "$c" in allwinner,*|rockchip,*|arm,*|qcom,*) ;; *,*) [ -z "$OZMA_BOARD" ] && ozma_board_try dt-compat "$c" ;; esac
    done
fi
if [ -z "$OZMA_BOARD" ]; then
    m=$({ tr -d '\0\r\n' < "$R/proc/device-tree/model"; } 2>/dev/null)
    case "$m" in ""|sun50i*|sun55i*|sun8i*) ;; *) ozma_board_try dt-model "$m" ;; esac
fi
# the weakest guess, the screen width on the Brick's chip: only where no source gave any name at all
if [ -z "$NAMED" ] && [ "$OZMA_SOC" = a133 ]; then
    w=$({ cut -d, -f1 < "$R/sys/class/graphics/fb0/virtual_size"; } 2>/dev/null)
    case "$w" in 1024|1280) ozma_board_try a133-fb "$w" ;; esac
fi
[ -n "$OZMA_BOARD_RAW" ] || OZMA_BOARD_RAW=":"
# No device tree means the Brick's chip above (as launch.sh always did). When an OS file names a board on another chip
# all the same, the chip is that board's (HW_SOC in its profile): it must not get the Brick's clocks and studio mode.
if [ -z "$OZMA_DT" ] && [ -n "$OZMA_BOARD" ]; then
    s=$(sed -n 's/^HW_SOC=//p' "$OZMA_PD/profiles/hw/board-$OZMA_BOARD.env" 2>/dev/null | head -n1 | tr -cd 'a-z0-9')
    if [ -n "$s" ] && [ "$s" != "$OZMA_SOC" ]; then OZMA_SOC=$s; ozma_why "no device tree: chip $s from the board's profile"; fi
fi

# ------------------------------------------------------------------ profiles: KEY=value lines, read never run
OZMA_PROFILE=""
ozma_load() {
    [ -f "$1" ] || return 0
    OZMA_PROFILE="$OZMA_PROFILE ${1##*/profiles/}"
    while IFS= read -r line || [ -n "$line" ]; do
        line=$(printf '%s' "$line" | tr -d '\r')
        case "$line" in ""|"#"*) continue ;; *=*) ;; *) continue ;; esac
        k=${line%%=*}; v=${line#*=}
        case "$k" in ""|*[!ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_]*) continue ;; esac
        eval "P_$k=\$v"
    done < "$1"
}
P="$OZMA_PD/profiles"
ozma_load "$P/safe.env"
ozma_load "$P/hw/soc-$OZMA_SOC.env"
[ -n "$OZMA_BOARD" ] && ozma_load "$P/hw/board-$OZMA_BOARD.env"
ozma_load "$P/os/$OZMA_OS.env"
[ -n "${BT_DATA:-}" ] && ozma_load "$BT_DATA/platform.override.env"

# ------------------------------------------------------------------ resolve: capability (HW_*) x policy (OS_*) -> BT_*
# Switches that exist today are exported ONLY when they turn something off (or on, for the stick), so the stock Brick
# gets exactly today's environment: nothing of the old keys is set there. New keys (BT_STUDIO_CLOCKS, BT_PAUSE_SERVICES,
# ...) are always exported; launch.sh reads them in step 1 instead of its inline checks.
ozma_set() { case "$OZMA_ENV0" in *" $1 "*) return 0 ;; esac; export "$1=$2"; OZMA_SET="$OZMA_SET $1=$2"; }
OZMA_SET=""
PW=0; [ "${P_OS_AUDIO:-}" = pipewire ] && PW=1
{ [ "${P_OS_AUDIO:-}" = direct-ok ] && [ "${P_HW_CODEC_DIRECT:-0}" = 1 ]; } || ozma_set BT_ALSA_DIRECT 0
# PipeWire's quantum: OZMA's own knob BT_PW_LATENCY, else the profile's; set even when the OS already exported one (as
# 0.9.1 did on Knulli), so the graph does not run 64-frame cycles under OZMA
if [ $PW = 1 ]; then PWL=${BT_PW_LATENCY:-${P_OS_PW_LATENCY:-}}; [ -n "$PWL" ] && { export PIPEWIRE_LATENCY="$PWL"; OZMA_SET="$OZMA_SET PIPEWIRE_LATENCY=$PWL"; }; fi
[ $PW = 1 ] && [ "${P_OS_USB_DIRECT:-1}" = 0 ] && ozma_set BT_AUDIO_OUT internal
# a sound server may still be coming up when the frontend starts OZMA: the app asks for the sound device again for this
# long before it falls back for the whole run. 3 s with PipeWire, a profile's OS_AUDIO_WAIT_MS wins, 0 = one
# try; never set on an OS without a sound server, so the Brick's environment does not change
AW=${P_OS_AUDIO_WAIT_MS:-}; [ -z "$AW" ] && [ $PW = 1 ] && AW=3000
case "$AW" in ""|0|*[!0123456789]*) ;; *) ozma_set BT_AUDIO_WAIT_MS "$AW" ;; esac
[ "${P_OS_STICK_DPAD:-0}" = 1 ] && ozma_set BT_STICK_AS_DPAD 1
# FN keys for PERFORM / QUICK MIX (hw/board-*.env from gen_board_profiles.py): told to the app only when fewer than two,
# so the Brick's environment does not change (ADAPT-4 / H1 reads it)
case "${P_HW_FN_KEYS:-2}" in 0|1) ozma_set BT_FN_KEYS "$P_HW_FN_KEYS" ;; esac
# the keys that ARE FN1 / FN2 on the board ("L3,R3"): the app names them in every text (never set on the Brick)
[ -n "${P_HW_FN_LABELS:-}" ] && ozma_set BT_FN_LABELS "$P_HW_FN_LABELS"
# what the texts call the device: told to the app only when it is not BRICK (the Brick's environment does not change)
case "${P_HW_DEVICE_WORD:-BRICK}" in BRICK) ;; *) ozma_set BT_DEVICE_WORD "$P_HW_DEVICE_WORD" ;; esac
{ [ "${P_OS_SYSFS:-0}" = 1 ] && [ "${P_HW_STUDIO:-0}" = 1 ]; } || ozma_set BT_STUDIO 0
if [ "${P_OS_SYSFS:-0}" = 1 ] && [ "${P_HW_STUDIO_CLOCKS:-0}" = 1 ]; then ozma_set BT_STUDIO_CLOCKS 1; else ozma_set BT_STUDIO_CLOCKS 0; fi
{ [ "${P_OS_SYSFS:-0}" = 1 ] && [ "${P_HW_USB_MODULES:-0}" = 1 ]; } || ozma_set BT_USB_HOSTFIX 0
[ "${P_HW_USB_MODULES:-0}" = 1 ] || ozma_set BT_USB_AVAIL 0
# codec mixers (speaker switch, mic gain): an OS whose sound server owns the codec keeps them, unless its profile says
# OZMA may still touch them (Knulli: today's 0.9.1 behaviour, OS_MIXERS=1)
MIX=0; [ $PW = 0 ] && MIX=1; MIX=${P_OS_MIXERS:-$MIX}
{ [ "${P_HW_SPEAKER_SWITCH:-0}" = 1 ] && [ "$MIX" = 1 ]; } || ozma_set BT_SPEAKER_CTL 0
{ [ "${P_HW_MIC:-0}" = 1 ] && [ "$MIX" = 1 ]; } || ozma_set BT_MIC_MIXER 0
[ -n "${P_HW_SCALE_QUALITY:-}" ] && ozma_set SDL_RENDER_SCALE_QUALITY "$P_HW_SCALE_QUALITY"
ozma_set BT_PAUSE_SERVICES "${P_OS_PAUSE_SERVICES:-}"
ozma_set BT_IDLE_INHIBIT "${P_OS_IDLE_INHIBIT:-none}"
ozma_set BT_LIB_PREPEND "${P_OS_LIB_PREPEND:-}"
ozma_set BT_FOREGROUND_FILE "${P_OS_FOREGROUND_FILE:-}"
ozma_set BT_RESERVED_COMBOS "${P_OS_RESERVED_COMBOS:-}"
ozma_set BT_POWER_KEY "${P_OS_POWER_KEY:-os}"
ozma_set BT_UPDATE "${P_OS_UPDATE:-notify}"
# YOUR OWN SAMPLES: one folder a person finds on every OS, <top of the card>/OZMA/Samples. Where the top is,
# first answer wins: BT_CARD_TOP (a user, a test); the profile's OS_CARD_TOP (a path, or "none" = this OS keeps to the
# app's own data/Samples); OZMA_CARD_TOP from the entry file (Knulli, muOS and the ports package know their layout);
# else two folders above an app folder that sits in App/ or Apps/ (the card zip: stock, spruce, CrossMix, NextUI,
# MinUI). No answer = nothing is set and the app shows data/Samples alone. Nothing is written here: launch.sh makes
# the folder. BT_SAMPLES_LABEL is how the app names the place in the sample list ("YOUR WAVS: ...").
# Only in a package whose app reads the folder: such a package carries platform/user_samples_note.txt (package.sh puts
# it in when the binary knows BT_USER_SAMPLES). Without the note nothing is set, so no folder ever appears that the
# app would not show.
UT=""
if [ -f "$OZMA_PD/user_samples_note.txt" ]; then
    UT=${BT_CARD_TOP:-}
    [ -z "$UT" ] && [ -n "${P_OS_CARD_TOP:-}" ] && { case "$P_OS_CARD_TOP" in /*) UT="$R$P_OS_CARD_TOP" ;; *) UT=$P_OS_CARD_TOP ;; esac; }
    [ -z "$UT" ] && UT=${OZMA_CARD_TOP:-}
    if [ -z "$UT" ] && [ -n "${APP_DIR:-}" ]; then
        UP=${APP_DIR%/*}
        case "${UP##*/}" in App|Apps) UT=${UP%/*} ;; esac
    fi
fi
case "$UT" in
    /) ;;
    /*) if [ -d "$UT" ]; then
            ozma_set BT_USER_SAMPLES "${UT%/}/OZMA/Samples"
            # the words for the place only with a folder: a person's empty BT_USER_SAMPLES= turns both off
            if [ -n "${BT_USER_SAMPLES:-}" ]; then ozma_set BT_SAMPLES_LABEL "${P_OS_SAMPLES_LABEL:-SD CARD > OZMA > SAMPLES}"; fi
        fi ;;
esac
OZMA_STATUS="${P_OS_STATUS:-experimental}"
# "reference", "tested" and "emulator" were earned on the TrimUI Brick only: any other board is experimental
case "$OZMA_STATUS" in reference|tested|emulator) [ "$OZMA_BOARD" = trimui-brick ] || OZMA_STATUS=experimental ;; esac
# "hold" (multi-platform rules: a pair held back without blocking a release): runs like experimental (tester report on),
# and UPDATE only tells about a new version even where the profile allows the install
[ "$OZMA_STATUS" = hold ] && [ "${BT_UPDATE:-}" != off ] && export BT_UPDATE=notify
export OZMA_OS OZMA_SOC OZMA_BOARD OZMA_BOARD_RAW OZMA_PROFILE OZMA_STATUS OZMA_WHY
# leave nothing behind in the launcher's shell but the answers (SD stays: launch.sh uses the same value)
unset R OSREL PLYM KNULLI_MARK MINUI_ENV NAMED ARKHOME c m w P PW PWL AW MIX UT UP line k v

# one human-readable block for log.txt / platform.txt / the ABOUT page
ozma_platform_report() {
    echo "os=$OZMA_OS soc=$OZMA_SOC board=${OZMA_BOARD:-?} raw=$OZMA_BOARD_RAW status=$OZMA_STATUS entry=${OZMA_ENTRY:-?}"
    echo "why: $OZMA_WHY"
    echo "profiles:$OZMA_PROFILE"
    echo "set:$OZMA_SET"
}
